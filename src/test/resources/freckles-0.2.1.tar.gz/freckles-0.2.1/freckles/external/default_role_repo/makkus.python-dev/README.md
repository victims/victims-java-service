python-dev
=========

An ansible role to install potential dependencies of a python project, create a virtualenv, and install the project into that virtualenv, ready for development work.

Requirements
------------

- TBC

Role Variables
--------------

Coming soon.

Dependencies
------------

TBC

Example Playbook
----------------

    - hosts: servers
      roles:
         - role: makkus.python-dev

License
-------

GPLv3

Author Information
------------------

Markus Binsteiner
