######################
freckles documentation
######################
`'configuration management for the rest of us'`

Welcome to the *freckles* documentation! *freckles* is a project to help you do configuration management on your local working environment. Find out more about how it works here:

.. toctree::
   :maxdepth: 2

   readme
   bootstrap
   usage
   code_overview

Indices and tables
******************

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
