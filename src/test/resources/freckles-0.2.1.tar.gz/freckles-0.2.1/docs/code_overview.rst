###########################
Code, contributing, credits
###########################

.. toctree::

   code
   contributing
   authors
   history
