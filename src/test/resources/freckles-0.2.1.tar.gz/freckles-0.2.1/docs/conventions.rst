Conventions

frecklecute

- locations

freckles

adapters

- locations
